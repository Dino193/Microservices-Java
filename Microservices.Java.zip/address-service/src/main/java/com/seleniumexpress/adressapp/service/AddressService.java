package com.seleniumexpress.adressapp.service;

import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seleniumexpress.adressapp.entity.Address;
import com.seleniumexpress.adressapp.repo.AddressRepo;
import com.seleniumexpress.adressapp.response.AdressResponse;

@Service
public class AddressService {
	
	@Autowired
	private AddressRepo addresRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	
	
	public List<AdressResponse> getAllAddress() {
		
		List<Address>allAddress=addresRepo.findAll();
		
		List<AdressResponse>addressList = Arrays.asList(modelMapper.map(allAddress,AdressResponse[].class));
		
		return addressList;
	}
	
	
	public AdressResponse findAddressByEmployeeId(int employeeId) {
		
		
		System.out.println("finding address for employee " +employeeId);
		
		Address address = addresRepo.findAddressByEmployeeId(employeeId);
		
		AdressResponse addressResponse = modelMapper.map(address, AdressResponse.class);
		
		return addressResponse;
			
		
	}




}
