package com.seleniumexpress.adressapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.seleniumexpress.adressapp.response.AdressResponse;
import com.seleniumexpress.adressapp.service.AddressService;


@RestController
public class AdressController {
	
	
	@Autowired
	private AddressService addressService;
	
	
	@GetMapping("/address/{employeeId}")
	public ResponseEntity<AdressResponse> getAddressByEmployeeId(@PathVariable("employeeId") int id) {
		
		AdressResponse addressResponse = null;
		
		addressResponse = addressService.findAddressByEmployeeId(id);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(addressResponse);
	}
	
	
	@GetMapping("address")
	public ResponseEntity<List<AdressResponse>>getAllAddress() {
		
		List<AdressResponse>addressReponse =addressService.getAllAddress();//fill in data
		
		return ResponseEntity.status(HttpStatus.OK).body(addressReponse);
		
	}
	
	

}
