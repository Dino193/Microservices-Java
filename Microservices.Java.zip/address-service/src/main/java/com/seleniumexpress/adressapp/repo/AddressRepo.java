package com.seleniumexpress.adressapp.repo;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import com.seleniumexpress.adressapp.entity.Address;

public interface AddressRepo extends JpaRepository<Address,Integer> {
	
	@Query(nativeQuery = true,value="SELECT employee.id,employee.name,employee.email,employee.bloodgroup,address.lane1,address.lane2,address.state,address.zip FROM address JOIN employee ON address.employee_id = employee.id WHERE address.employee_id = 1;")
	Address findAddressByEmployeeId(@Param("employeeId") int employeeId);

	
	
}

