package com.seleniumexpress.employeeapp.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.ResponseEntity;

import com.seleniumexpress.employeeapp.entity.Employee;
import com.seleniumexpress.employeeapp.openfeignclients.AddressClient;
import com.seleniumexpress.employeeapp.repo.*;
import com.seleniumexpress.employeeapp.response.AdressResponse;
import com.seleniumexpress.employeeapp.response.EmployeeResponse;
import org.springframework.cloud.client.discovery.DiscoveryClient;

import org.springframework.cloud.client.ServiceInstance;

import java.util.Arrays;
import java.util.List;


@Service
public class EmployeeService {
	
	
	@Autowired
	private EmployeeRepo EmployeeRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private WebClient webClient;
	
	
	//koristimo za api
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AddressClient addressClient;
	
	//@Autowired
	//private DiscoveryClient discoveryClient;
	
	//@Autowired
   // private LoadBalancerClient loadBalancerClient;
	
	
	public List<EmployeeResponse> getAllEmployees() {
		
		List<Employee>employeeList= EmployeeRepo.findAll();
		
		List<EmployeeResponse>employeesResponse=Arrays.asList(modelMapper.map(employeeList, EmployeeResponse[].class));
		
		
	    ResponseEntity<List<AdressResponse>> allAddress = addressClient.getAllAddress();
		List<AdressResponse>addressResponse = allAddress.getBody();
		
		employeesResponse.forEach(employee ->{
		
		    for(AdressResponse addrResponse : addressResponse) {
		    	
		    	if(addrResponse.getId() == employee.getId()) {
		    		
		    		employee.setAddressResponse(addrResponse);
		    			
			employee.setAddressResponse(addrResponse);
		    	
		    	}
		    }
		
		});
		    
		return employeesResponse;
	}
	

		
	public EmployeeResponse getEmployeeById(int id) {
		
		
		Employee employee = EmployeeRepo.findById(id).get();
		
		EmployeeResponse employeeResponse = modelMapper.map(employee,EmployeeResponse.class);
        
		//set data by making a rest api call
		ResponseEntity<AdressResponse>addressResponseEntity=addressClient.getAddressByEmployeeId(id);
		AdressResponse addressResponse = addressResponseEntity.getBody();
				                         
	    employeeResponse.setAddressResponse(addressResponse);
		
		return employeeResponse;
			
	}
	
	private AdressResponse callToAddressServiceUsingWebClient(int id) {
		
		
		return webClient
                .get()
                .uri("/address/"+id)
                .retrieve()
                .bodyToMono(AdressResponse.class)
                .block();
                
		
	}
	
		
	private AdressResponse callingAddressServiceUsingRESTTemplate(int id) {
		
		//get me details for the ip and port number for address service ,so i dont hardcore
		
	//	List<ServiceInstance>instances=discoveryClient.getInstances("address-service");
		
		//ServiceInstance serviceInstance = instances.get(0);
		
		//String uri =serviceInstance.getUri().toString();
		
		/*ServiceInstance serviceInstance = loadBalancerClient.choose("address-service");
		String uri = serviceInstance.getUri().toString();
		
		String contextRoot = serviceInstance.getMetadata().get("configPath");
		System.out.println(serviceInstance.getMetadata().get("user"));
		
		System.out.println("uri >>>>>>>>>>>"+uri+contextRoot);
		*/
		return restTemplate.getForObject("http://address-service/address-app/api/address/{id}",AdressResponse.class,id);
	}

	
}
