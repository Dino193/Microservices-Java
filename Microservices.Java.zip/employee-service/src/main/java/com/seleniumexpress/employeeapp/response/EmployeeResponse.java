package com.seleniumexpress.employeeapp.response;

public class EmployeeResponse {
	
	
	private int id;
	
	private String name;
	
	private String email;
	
	private String bloogGroup;
	
	private AdressResponse addressResponse;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBloogGroup() {
		return bloogGroup;
	}

	public void setBloogGroup(String bloogGroup) {
		this.bloogGroup = bloogGroup;
	}

	public AdressResponse getAddressResponse() {
		return addressResponse;
	}

	public void setAddressResponse(AdressResponse addressResponse) {
		this.addressResponse = addressResponse;
	}
	
	

	
	

}
