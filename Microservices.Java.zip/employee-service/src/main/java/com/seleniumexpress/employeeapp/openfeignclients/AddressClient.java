package com.seleniumexpress.employeeapp.openfeignclients;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.seleniumexpress.adressapp.response.AdressResponse;

@FeignClient(name="ADDRESS-SERVICE",path = "/address-app/api/")//Eureka Instance Name,mora da dodelim ime da bi radilo 
public interface AddressClient {
	
	
	@GetMapping("/address/{employeeId}")
	public ResponseEntity<com.seleniumexpress.employeeapp.response.AdressResponse> getAddressByEmployeeId(@PathVariable("employeeId") int id);

	
	 @GetMapping("/address")
	 public ResponseEntity<List<com.seleniumexpress.employeeapp.response.AdressResponse>> getAllAddress(); 
	
	
}

